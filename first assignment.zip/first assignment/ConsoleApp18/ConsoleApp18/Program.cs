﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp18
{
    class Program
    {
        static void Main(string[] args)
        {
            //Stack<int> st= new Stack<int>();
            ////st.Push(10);
            ////st.Push(30);
            ////st.Push(20);
            ////st.Push(40);
            ////st.Push(55);
            //Stack<int> rev = new Stack<int>();
            //st.Push(12);
            //st.Push(45);
            //st.Push(4);
            //st.Push(67);
            //Console.WriteLine("my stack values are");
            //foreach (int x in st)
            //{
            //    Console.WriteLine(x);
            //}



            //Console.WriteLine();
            //while (st.Count != 0)
            //{
            //    rev.Push(st.Pop());
            //}



            ////st.Pop();



            ////Console.WriteLine("removed element from stack  :" + st.Pop());



            //Console.WriteLine("reverse Array is:" + rev.Reverse());
            //foreach(int x1 in rev)
            //{
            //    Console.WriteLine(x1);
            //}
            List<Employee> emp = new List<Employee>();
            emp.Add(new Employee() { EmpId = 1, EmpName = "ekta" });
            emp.Add(new Employee() { EmpId = 10, EmpName = "aishu" });



            emp.Add(new Employee() { EmpId = 6, EmpName = "gauri" });
            emp.Add(new Employee() { EmpId = 20, EmpName = "xyz" });
            emp.Add(new Employee() { EmpId = 11, EmpName = "abc" });



            Console.WriteLine("before sort");
            foreach (Employee x in emp)
            {
                Console.WriteLine(x);
            }



            emp.Sort();



            Console.WriteLine("after sort");
            foreach (Employee x1 in emp)
            {
                Console.WriteLine(x1);
            }




            Console.ReadLine();
        }
    }
}
