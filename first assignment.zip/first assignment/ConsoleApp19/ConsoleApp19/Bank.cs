﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp19
{
    public class Bank
    {
       public int NetBalance1;
        public int TranAmount;

        public Bank(int NetBalance1,int TranAmount)
        {
            this.NetBalance1 = NetBalance1;
            this.TranAmount = TranAmount;

        }

        public int NetBalance
        {
            get { return NetBalance1; }
            set { NetBalance1 = value; }
        }

       public void Deposit()
        {
            NetBalance = NetBalance + TranAmount;
            Console.WriteLine("deposit..." + NetBalance);
        }



       public void Withdrawal()
        {

            NetBalance = NetBalance - TranAmount;
            Console.WriteLine("withdraw..." + NetBalance);
        }
    }
}
