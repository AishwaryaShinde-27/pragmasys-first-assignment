﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleApp19
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank b = new Bank(20000, 10000);
            // b.NetBalance = 1000;
            // b.Deposit(100);
            // b.Withdrawal(50);
            Thread t1 = new Thread(b.Deposit);
            Thread t2 = new Thread(b.Withdrawal);
            t1.Start();
            t2.Start();
        }
    }
}
