﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = { "aishu", "ekta", "gauri", "shivu", "pranju", "pooja" };
            foreach (string i in arr)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();

            //for (int i = 0; arr.Length[] !="\0"; i++)

            //{
            foreach (var item in arr)
            {
                if (item.Length % 2 != 0 && item.Contains("a") == true)
                {
                    Console.WriteLine(item);
                }
            }
            //}
            Console.ReadLine();

           



           

        }
    }
}
